function updateProjectName() {
    const name = document.getElementById("inputProjectName").value;
    if (name.trim() === "") return alert("Digite um nome válido.");

    document.getElementById("project-name").innerText = name;
}

// Salvar descrição
function saveDescricao() {
    const motivacao = document.getElementById("motivacao").value;
    const objetivo = document.getElementById("objetivo").value;
    const contexto = document.getElementById("contexto").value;
    const output = document.getElementById("descricaoOutput");

    output.innerHTML = `
        <h3>Descrição Completa</h3>
        <p><strong>Motivação:</strong> ${motivacao}</p>
        <p><strong>Objetivo:</strong> ${objetivo}</p>
        <p><strong>Contextualização:</strong> ${contexto}</p>
    `;
    output.style.display = "block";
}

// Pré-visualizar a imagem do esquema
document.getElementById("imagemEsquema").addEventListener("change", function (event) {
    const file = event.target.files[0];
    const preview = document.getElementById("previewImagem");

    if (!file) return;

    const reader = new FileReader();
    reader.onload = function () {
        preview.innerHTML = `<img src="${reader.result}" alt="Esquema Conceitual">`;
    };
    reader.readAsDataURL(file);
});